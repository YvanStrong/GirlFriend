
package girlfriend;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

public class functionclass {
    public  static Connection con1(){
        try {Connection con2;
            Class.forName("com.mysql.jdbc.Driver");
            con2=DriverManager.getConnection("jdbc:mysql://localhost/freind","root","");
            
                  return con2;  } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
     
    }return null;
}
    public static java.sql.Date sqlDate(long sn)
    {
        java.sql.Date sqld=new java.sql.Date(sn);
        return sqld;
    }
    public static String date(java.util.Date p,long d)
    {
        long dys1 = TimeUnit.MILLISECONDS.convert(d, TimeUnit.DAYS );
        long de= p.getTime()+dys1;
        String pr=convert(new Date(de));
        return pr;
    }
     public static String convert(java.util.Date d)
    {
        SimpleDateFormat s=new SimpleDateFormat("d-M-yyyy");
       String c=s.format(d);
        return c;
    }
    
}
