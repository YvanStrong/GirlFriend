package girlfriend;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.concurrent.TimeUnit;

public class myClass

{

    public static void main(String[] args)

    {

        myClass tdt = new myClass();

        tdt.doMath();

    }

   

    /**

     * method to create a calendar object, add 2m 1d, and print result

     */

    private void doMath()

    {

        // set calendar to 1 Jan 2007

        Calendar calendar = new GregorianCalendar(2007,Calendar.JANUARY,1);

        System.out.println("Starting date is: ");

        printCalendar(calendar);

        // add 2m 1d

        System.out.println("Adding 2m 1d... ");

        calendar.add(Calendar.MONTH,2);

        calendar.add(Calendar.DAY_OF_MONTH,1);

       

        // print ending date value

        System.out.println("Ending date is: ");

        printCalendar(calendar);
      Date d= new Date();
        long dys1 = TimeUnit.MILLISECONDS.convert(96, TimeUnit.DAYS );
        long de= new Date().getTime()+TimeUnit.MILLISECONDS.convert(96, TimeUnit.DAYS );;
        d=new Date(new Date().getTime()-TimeUnit.MILLISECONDS.convert(32, TimeUnit.DAYS ));
System.out.println("Ending date is: "+ dys1);
System.out.println("Ending date is: "+ d);
    }

   

    /**

     * utility method to print a Calendar object using SimpleDateFormat.

     * @param calendar calendar object to be printed.

     */

    private void printCalendar(Calendar calendar)

    {

        // define output format and print

        SimpleDateFormat sdf = new SimpleDateFormat("d MMM yyyy hh:mm aaa");

        String date = sdf.format(calendar.getTime());

        System.out.println(date);

    }

}